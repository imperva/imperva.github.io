# Copyright 2018 Imperva. All rights reserved.
 
from imperva_sdk.core import *
from imperva_sdk.MxConnection import MxConnection

__version__ = '0.1.8'
__author__ = "Imperva Inc."

