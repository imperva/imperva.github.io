imperva-sdk
===========

imperva-sdk is an Imperva SecureSphere Open API SDK for Python, which allows Python developers to write software that communicates with the SecureSphere MX. imperva-sdk provides an easy to use, object-oriented API in addition to JSON export/import capabilities.

`Download latest package <https://imperva.github.io/imperva-sdk-python/quickstart.html#downloads>`_

`Documentation <https://imperva.github.io/imperva-sdk-python/>`_
